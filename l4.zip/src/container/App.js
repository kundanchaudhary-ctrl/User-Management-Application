
import './App.css';
import React,{ Component } from 'react';
import Persons from "../components/Persons/Persons";
import Cockpit from './../components/Cockpit/Cockpit';
  // container managing state
  //now we have clearly focused components 
  //You should have clear responsibilities of your components,have them narrowly focused,
  //use as many functional components as possible 
  //and have your containers as lean as possible when it comes to JSX and styling
  //Some containers might not even have the style file coz they import other comp.
  //already having css files
  class App extends Component
  {
    constructor(props) {
      super(props);
      this.state = {
        error: null,
        isLoaded: false,
        items: []
      };
    }
      componentDidMount() {
        fetch("https://regres.in/api/users")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                items: result.data
              });
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
          console.log(this.state.items);
      }


  render() {
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <ul>
          {items.map(item => (
            <li key={item.id}>
              {item.name} {item.price}
            </li>
          ))}
        </ul>
      );
    }
  }
}
export default App;
    
